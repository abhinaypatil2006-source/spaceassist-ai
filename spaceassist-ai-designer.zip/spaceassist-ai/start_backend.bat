@echo off
REM ============================================================
REM SpaceAssist AI - Backend Launcher
REM Double-click this file (or run it from cmd) to set up and
REM start the backend automatically. Safe to run multiple times.
REM ============================================================

cd /d "%~dp0backend"

echo.
echo ============================================================
echo  SpaceAssist AI - Backend Setup
echo ============================================================
echo.

if not exist venv (
    echo [1/3] Creating virtual environment...
    python -m venv venv
) else (
    echo [1/3] Virtual environment already exists, skipping.
)

call venv\Scripts\activate.bat

echo [2/3] Installing core dependencies (fast, no camera/AI libs yet)...
pip install --quiet fastapi uvicorn[standard] sqlalchemy pydantic python-multipart websockets

echo [3/3] Starting backend on http://127.0.0.1:8000 ...
echo.
echo   API docs:      http://127.0.0.1:8000/docs
echo   Leave this window open while demoing. Press CTRL+C to stop.
echo.
echo   NOTE: Camera Mode needs extra packages (opencv-python,
echo   mediapipe, torch). Demo Mode works fully without them.
echo   To enable Camera Mode later, run:
echo       pip install -r requirements.txt
echo   in this same venv, then restart this script.
echo.

uvicorn main:app --reload --host 127.0.0.1 --port 8000

pause
