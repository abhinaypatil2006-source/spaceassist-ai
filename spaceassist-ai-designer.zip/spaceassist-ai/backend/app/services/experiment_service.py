"""
ExperimentService bridges the in-memory ExperimentStateMachine with
SQLite persistence. For this prototype there is a single active
experiment at a time (no multi-user auth) — that's enough for a
hackathon demo running on one laptop.
"""

from datetime import datetime
from sqlalchemy.orm import Session

from app.experiment.state_machine import (
    ExperimentStateMachine,
    STEP_SEQUENCE,
    STEP_DISPLAY_NAMES,
)
from app.models.models import Experiment, ExperimentStep, ActivityEvent, Alert
from app.ai.activity_model import activity_model

DEFAULT_EXPERIMENT_NAME = "Sample Processing Experiment"


class ExperimentService:
    def __init__(self):
        self.machine = ExperimentStateMachine()
        self.experiment_id = None
        self.mode = "DEMO"
        self.name = DEFAULT_EXPERIMENT_NAME

    def start(self, db: Session, mode: str = "DEMO") -> dict:
        """Start the built-in Sample Processing Experiment."""
        self.machine.start()
        self.mode = mode
        self.name = DEFAULT_EXPERIMENT_NAME

        experiment = Experiment(
            name=self.name,
            mode=mode,
            status="IN_PROGRESS",
            current_step_index=0,
            started_at=datetime.utcnow(),
        )
        db.add(experiment)
        db.commit()
        db.refresh(experiment)

        for i, step_key in enumerate(STEP_SEQUENCE):
            db.add(ExperimentStep(
                experiment_id=experiment.id,
                step_index=i,
                step_name=STEP_DISPLAY_NAMES[step_key],
                status="PENDING",
            ))
        db.commit()

        self.experiment_id = experiment.id
        self._log_alert(db, "INFO", "Experiment started.")
        return self.get_state()

    def start_custom(self, db: Session, name: str, steps: list[str]) -> dict:
        """
        Start a user-defined science experiment — any procedure typed
        in as a list of plain-text steps. Guided manually (via
        `advance()`) since there's no trained model to recognize
        arbitrary, freshly-typed activities from a camera.
        """
        self.machine.start(custom_steps=steps)
        self.mode = "CUSTOM"
        self.name = name or "Custom Experiment"

        experiment = Experiment(
            name=self.name,
            mode="CUSTOM",
            status="IN_PROGRESS",
            current_step_index=0,
            started_at=datetime.utcnow(),
        )
        db.add(experiment)
        db.commit()
        db.refresh(experiment)

        for i, step_text in enumerate(steps):
            db.add(ExperimentStep(
                experiment_id=experiment.id,
                step_index=i,
                step_name=step_text,
                status="PENDING",
            ))
        db.commit()

        self.experiment_id = experiment.id
        self._log_alert(db, "INFO", f"Custom experiment '{self.name}' started with {len(steps)} steps.")
        return self.get_state()

    def reset(self, db: Session) -> dict:
        self.machine.reset()
        self.experiment_id = None
        self.name = DEFAULT_EXPERIMENT_NAME
        return self.get_state()

    def predict(self, db: Session, activity: str, confidence: float) -> dict:
        """Confidence-driven advancement — used by Demo Mode and (eventually) Camera Mode."""
        result = self.machine.process(activity, confidence)
        return self._apply_result(db, result, confidence)

    def advance(self, db: Session) -> dict:
        """
        Manual advancement — a person confirming a step is done, no
        confidence score involved. This is how custom (typed-in)
        experiments are guided, and can also step through the default
        experiment by hand.
        """
        result = self.machine.manual_advance()
        return self._apply_result(db, result, confidence=100.0)

    def _apply_result(self, db: Session, result: dict, confidence: float) -> dict:
        """Shared DB-logging logic for both predict() and advance()."""
        display_names = self.machine.display_names

        if self.experiment_id is not None and result["expected"] is not None:
            event = ActivityEvent(
                experiment_id=self.experiment_id,
                timestamp=result["timestamp"],
                expected=display_names.get(result["expected"], str(result["expected"])),
                detected=display_names.get(result["detected"], str(result["detected"])),
                confidence=confidence,
                status=result["status"],
            )
            db.add(event)

            if result["status"] == "SEQUENCE_ERROR":
                self._log_alert(db, "ERROR", result["message"])
            elif result["status"] in ("LOW_CONFIDENCE", "UNKNOWN_ACTION"):
                self._log_alert(db, "WARNING", result["message"])
            elif result["status"] == "COMPLETED":
                self._log_alert(db, "INFO", "Experiment completed successfully.")
                exp = db.query(Experiment).filter(Experiment.id == self.experiment_id).first()
                if exp:
                    exp.status = "COMPLETED"
                    exp.completed_at = datetime.utcnow()

            exp = db.query(Experiment).filter(Experiment.id == self.experiment_id).first()
            if exp:
                exp.current_step_index = self.machine.current_index

            db.commit()

        # datetime isn't JSON serializable by default in a plain dict response
        result = dict(result)
        result["timestamp"] = result["timestamp"].isoformat()
        return result

    def _log_alert(self, db: Session, level: str, message: str):
        alert = Alert(
            experiment_id=self.experiment_id,
            timestamp=datetime.utcnow(),
            level=level,
            message=message,
        )
        db.add(alert)
        db.commit()

    def get_state(self) -> dict:
        state = self.machine.get_state()
        return {
            "experiment_id": self.experiment_id,
            "name": self.name,
            "mode": self.mode,
            # Genuinely dynamic (Phase 7): reflects whether a real
            # checkpoint was found and loaded by ActivityModel, not a
            # hardcoded string. Today it's always False because no
            # model has been trained — but this line will flip to
            # "ONLINE" the moment a real activity_lstm.pt exists.
            "ai_status": "ONLINE" if activity_model.is_trained() else "AI_MODEL_NOT_TRAINED",
            **state,
        }


# Single shared instance for this prototype.
experiment_service = ExperimentService()
