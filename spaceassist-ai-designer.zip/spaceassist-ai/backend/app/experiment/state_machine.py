"""
Experiment State Machine

This is the core logic of SpaceAssist AI. It has nothing to do with
Demo Mode or Camera Mode — it simply receives a stream of
(activity, confidence) predictions, one at a time, and decides
whether the experiment is progressing correctly.

Design rules (per spec):
  - The expected sequence is fixed: Pick -> Open -> Add -> Close -> Place -> Record
  - A single noisy/low-confidence frame must NOT change experiment state
  - The correct activity must be seen for several consecutive frames
    ("stability") before the step is marked complete and we advance
  - A wrong activity immediately raises SEQUENCE_ERROR (and resets the
    stability buffer), but does NOT skip or corrupt the current step

This also supports CUSTOM experiments (any science procedure typed in
as a list of steps, not just the built-in Sample Processing
Experiment). A custom experiment has no AI/confidence behind it —
there's no trained model to recognize "typed-in" activities — so it's
advanced manually via `manual_advance()` instead of `process()`. This
is an honest design choice: it guides an astronaut through arbitrary
steps without pretending a camera is recognizing them.
"""

from datetime import datetime

STEP_SEQUENCE = [
    "Pick_Container",
    "Open_Container",
    "Add_Sample",
    "Close_Container",
    "Place_Analyzer",
    "Record_Result",
]

STEP_DISPLAY_NAMES = {
    "Pick_Container": "Pick Container",
    "Open_Container": "Open Container",
    "Add_Sample": "Add Sample",
    "Close_Container": "Close Container",
    "Place_Analyzer": "Place Container in Analyzer",
    "Record_Result": "Record Result",
}

# Confidence bands (configurable)
HIGH_CONFIDENCE_THRESHOLD = 80.0
LOW_CONFIDENCE_THRESHOLD = 50.0

# Number of consecutive matching frames required before a step advances
STABILITY_FRAMES = 3


class ExperimentStateMachine:
    def __init__(self,
                 stability_frames: int = STABILITY_FRAMES,
                 high_conf: float = HIGH_CONFIDENCE_THRESHOLD,
                 low_conf: float = LOW_CONFIDENCE_THRESHOLD):
        self.stability_frames = stability_frames
        self.high_conf = high_conf
        self.low_conf = low_conf
        self.reset()

    def reset(self):
        self.steps = list(STEP_SEQUENCE)
        self.display_names = dict(STEP_DISPLAY_NAMES)
        self.is_custom = False
        self.current_index = 0
        self.status = "NOT_STARTED"
        self._buffer = []
        self.started = False
        self.completed = False

    def start(self, custom_steps: list[str] | None = None):
        """
        Start a fresh run. If `custom_steps` is given (a list of plain
        text step descriptions typed in by the user), the machine
        tracks that arbitrary procedure instead of the built-in Sample
        Processing Experiment. Custom runs are advanced with
        `manual_advance()`, not `process()` — there's no AI behind a
        typed-in procedure to produce confidence scores for.
        """
        self.reset()
        if custom_steps:
            # Internal keys just need to be unique and stable; the
            # actual step text lives in display_names and is what's
            # shown and logged everywhere.
            self.steps = [f"custom_step_{i}" for i in range(len(custom_steps))]
            self.display_names = {
                f"custom_step_{i}": text for i, text in enumerate(custom_steps)
            }
            self.is_custom = True
        self.status = "IN_PROGRESS"
        self.started = True

    @property
    def expected_activity(self):
        if self.current_index >= len(self.steps):
            return None
        return self.steps[self.current_index]

    def process(self, activity: str, confidence: float) -> dict:
        """
        Process a single (activity, confidence) prediction and return
        a result dict describing what happened. This is called once per
        "frame" (in Demo Mode, once per simulated step; in Camera Mode,
        once per processed window of video frames). Not used for
        custom experiments — see `manual_advance()`.
        """
        timestamp = datetime.utcnow()

        if not self.started:
            return self._result("NOT_STARTED", None, activity, confidence, timestamp,
                                 "Experiment has not been started yet.")

        if self.completed:
            return self._result("COMPLETED", None, activity, confidence, timestamp,
                                 "Experiment already completed.")

        expected = self.expected_activity

        # 1. Confidence too low -> ignore this frame entirely
        if confidence < self.low_conf:
            self._buffer.clear()
            return self._result("LOW_CONFIDENCE", expected, activity, confidence, timestamp,
                                 "AI confidence is too low to trust this prediction.")

        # 2. Recognizer could not classify the action
        if activity == "Unknown_Action":
            self._buffer.clear()
            return self._result("UNKNOWN_ACTION", expected, activity, confidence, timestamp,
                                 "Activity could not be recognized.")

        # 3. Wrong activity for the current step
        if activity != expected:
            self._buffer.clear()
            return self._result(
                "SEQUENCE_ERROR", expected, activity, confidence, timestamp,
                f"Expected '{self.display_names.get(expected, expected)}' but detected "
                f"'{self.display_names.get(activity, activity)}'. "
                f"Perform '{self.display_names.get(expected, expected)}' before continuing."
            )

        # 4. Correct activity -> accumulate stability buffer
        self._buffer.append(activity)
        self._buffer = self._buffer[-self.stability_frames:]

        if len(self._buffer) < self.stability_frames or any(a != expected for a in self._buffer):
            return self._result("PENDING", expected, activity, confidence, timestamp,
                                 "Correct activity detected, confirming stability.")

        # 5. Stable + correct across N frames -> advance to next step
        self._buffer.clear()
        self.current_index += 1

        if self.current_index >= len(self.steps):
            self.status = "COMPLETED"
            self.completed = True
            return self._result("COMPLETED", expected, activity, confidence, timestamp,
                                 "Experiment completed successfully.")

        return self._result("CORRECT", expected, activity, confidence, timestamp,
                             f"Step '{self.display_names.get(expected, expected)}' confirmed.")

    def manual_advance(self) -> dict:
        """
        Mark the current step done and move to the next one — no
        confidence, no AI, just a person confirming "I did this step."
        This is how CUSTOM (typed-in) experiments are guided, and can
        also be used to manually step through the default experiment
        during testing/demoing without a camera or curl.
        """
        timestamp = datetime.utcnow()

        if not self.started:
            return self._result("NOT_STARTED", None, None, 100.0, timestamp,
                                 "Experiment has not been started yet.")
        if self.completed:
            return self._result("COMPLETED", None, None, 100.0, timestamp,
                                 "Experiment already completed.")

        expected = self.expected_activity
        self.current_index += 1

        if self.current_index >= len(self.steps):
            self.status = "COMPLETED"
            self.completed = True
            return self._result("COMPLETED", expected, expected, 100.0, timestamp,
                                 "Experiment completed successfully.")

        return self._result("CORRECT", expected, expected, 100.0, timestamp,
                             f"Step '{self.display_names.get(expected, expected)}' marked complete.")

    def _result(self, status, expected, detected, confidence, timestamp, message) -> dict:
        return {
            "status": status,
            "expected": expected,
            "detected": detected,
            "confidence": confidence,
            "current_step_index": self.current_index,
            "progress": f"{self.current_index}/{len(self.steps)}",
            "completed": self.completed,
            "message": message,
            "timestamp": timestamp,
        }

    def get_state(self) -> dict:
        """Full snapshot used to render the dashboard."""
        steps_info = []
        for i, s in enumerate(self.steps):
            if i < self.current_index:
                step_status = "CORRECT"
            elif i == self.current_index and self.started and not self.completed:
                step_status = "IN_PROGRESS"
            else:
                step_status = "PENDING"
            steps_info.append({
                "step_index": i,
                "step_name": self.display_names.get(s, s),
                "status": step_status,
            })

        return {
            "status": self.status,
            "is_custom": self.is_custom,
            "current_step_index": self.current_index,
            "total_steps": len(self.steps),
            "progress": f"{self.current_index}/{len(self.steps)}",
            "steps": steps_info,
        }
