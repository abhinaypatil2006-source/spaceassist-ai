"""
Pose Detector Module — Phase 6: MediaPipe Pose + Hand Landmarks

This module's ONLY job is to find a person in a frame, draw their body
and hand landmarks on it, and hand back the raw joint coordinates.
Turning that landmark data into a recognized *activity* (Pick
Container, Open Container, etc.) is deliberately a separate concern —
that's Phase 7's activity_model.py. Keeping detection and recognition
apart is what the spec calls a "modular activity-recognition
interface," and it also means this file works and is testable on its
own, with no camera and no trained model required.

Uses MediaPipe's classic `solutions` API (Pose + Hands), pinned to
mediapipe==0.10.14 in requirements.txt specifically because that
version ships its models bundled inside the pip package — no extra
model download or internet connection needed the first time Camera
Mode runs, which matters for a laptop that might demo somewhere
without wifi.

Defensive by design: if mediapipe isn't installed — OR is installed
but is a newer version that removed the classic `solutions` API in
favor of a different "Tasks" API (this genuinely happens: mediapipe
0.10.14 has `mp.solutions`, but 0.10.2x+ builds may not) — every
method reports that clearly instead of raising an AttributeError that
would otherwise crash the whole backend on startup.
"""

try:
    import mediapipe as mp
    # Importing mediapipe can succeed even when the classic `solutions`
    # API isn't present (newer releases moved to a different "Tasks"
    # API). Check for the actual attribute, not just a successful
    # import, so a version mismatch degrades gracefully instead of
    # crashing main.py at startup with an AttributeError.
    if not hasattr(mp, "solutions"):
        raise ImportError(
            "This mediapipe version does not have the 'solutions' API "
            "(mp.solutions.pose). Run: pip install mediapipe==0.10.14"
        )
    MEDIAPIPE_AVAILABLE = True
except Exception:
    mp = None
    MEDIAPIPE_AVAILABLE = False

# The specific joints the spec asks for: shoulders, elbows, wrists,
# hips, knees, ankles. This is the exact sequence Phase 7's
# activity_model.py will consume as its input features.
_TRACKED_JOINTS = [
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]


class PoseDetector:
    """Wraps MediaPipe Pose + Hands for a single camera stream."""

    def __init__(self, min_detection_confidence=0.5, min_tracking_confidence=0.5):
        self._pose = None
        self._hands = None
        self._mp_pose = None
        self._mp_hands = None
        self._drawing = None
        self._drawing_styles = None

        if MEDIAPIPE_AVAILABLE:
            self._mp_pose = mp.solutions.pose
            self._mp_hands = mp.solutions.hands
            self._drawing = mp.solutions.drawing_utils
            self._drawing_styles = mp.solutions.drawing_styles
            self._pose = self._mp_pose.Pose(
                min_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence,
            )
            self._hands = self._mp_hands.Hands(
                min_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence,
                max_num_hands=2,
            )

    def is_available(self) -> bool:
        return MEDIAPIPE_AVAILABLE

    def process(self, frame_bgr):
        """
        Runs pose + hand detection on a BGR frame (as read by OpenCV)
        and draws landmarks directly onto it in place.

        Returns (annotated_frame, result_dict) where result_dict is:
            {
                "available": bool,        # was MediaPipe even installed?
                "person_detected": bool,
                "hands_detected": int,    # 0, 1, or 2
                "landmarks": {            # only populated if a person was found
                    "left_shoulder": {"x":.., "y":.., "z":.., "visibility":..},
                    ...
                },
            }
        """
        if not MEDIAPIPE_AVAILABLE:
            return frame_bgr, {
                "available": False,
                "person_detected": False,
                "hands_detected": 0,
                "landmarks": {},
            }

        import cv2  # local import — app/ai/camera.py already guards for cv2 being optional

        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        pose_result = self._pose.process(rgb)
        hands_result = self._hands.process(rgb)
        rgb.flags.writeable = True

        person_detected = pose_result.pose_landmarks is not None
        landmarks = {}

        if person_detected:
            self._drawing.draw_landmarks(
                frame_bgr,
                pose_result.pose_landmarks,
                self._mp_pose.POSE_CONNECTIONS,
                landmark_drawing_spec=self._drawing_styles.get_default_pose_landmarks_style(),
            )
            landmarks = self._extract_tracked_joints(pose_result.pose_landmarks)

        hands_detected = 0
        if hands_result.multi_hand_landmarks:
            hands_detected = len(hands_result.multi_hand_landmarks)
            for hand_landmarks in hands_result.multi_hand_landmarks:
                self._drawing.draw_landmarks(
                    frame_bgr,
                    hand_landmarks,
                    self._mp_hands.HAND_CONNECTIONS,
                    self._drawing_styles.get_default_hand_landmarks_style(),
                    self._drawing_styles.get_default_hand_connections_style(),
                )

        return frame_bgr, {
            "available": True,
            "person_detected": person_detected,
            "hands_detected": hands_detected,
            "landmarks": landmarks,
        }

    def _extract_tracked_joints(self, pose_landmarks):
        mp_pose = self._mp_pose
        landmark_enum = mp_pose.PoseLandmark
        out = {}
        for joint_name in _TRACKED_JOINTS:
            enum_member = landmark_enum[joint_name.upper()]
            lm = pose_landmarks.landmark[enum_member]
            out[joint_name] = {
                "x": round(lm.x, 4),
                "y": round(lm.y, 4),
                "z": round(lm.z, 4),
                "visibility": round(lm.visibility, 4),
            }
        return out

    def close(self):
        if self._pose is not None:
            self._pose.close()
        if self._hands is not None:
            self._hands.close()


# Single shared instance — one camera, one detector, one prototype.
pose_detector = PoseDetector()
