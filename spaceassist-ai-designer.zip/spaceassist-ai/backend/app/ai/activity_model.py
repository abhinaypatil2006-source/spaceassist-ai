"""
Activity Recognition Model Interface — Phase 7

This is deliberately the smallest, most honest module in the whole
project. Its entire job is:

    predict(sequence) -> {"activity": "...", "confidence": 0.0}

There is NO trained model behind this yet — no dataset was collected
or labeled for this hackathon prototype, and the spec is explicit that
faking it is worse than saying so. So `predict()` always returns:

    {"activity": "AI_MODEL_NOT_TRAINED", "confidence": 0.0, "trained": False}

...instead of a made-up label with a made-up confidence score. Camera
Mode (Phase 5/6) already extracts the exact landmark sequence this
module expects — shoulders, elbows, wrists, hips, knees, ankles, per
frame — so training a real model later is a matter of collecting
labeled sequences and swapping the body of `predict()`, without
touching camera.py, pose_detector.py, or the experiment state machine
at all.

The LSTM class below is real, working architecture — not a comment
saying "add LSTM here" — but it is never instantiated with trained
weights, and is never used in `predict()` unless a checkpoint file
actually exists on disk. Guarded like every other optional dependency
in this project: if torch isn't installed, `predict()` still works
and still returns the same honest response.
"""

import os

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except Exception:
    # Deliberately broad, not just ImportError: a corrupted or
    # incompatible torch install (missing shared libraries, a CUDA/
    # driver mismatch, etc.) can fail in ways that aren't a clean
    # ImportError. Any failure here should degrade to "not available"
    # rather than crash the whole backend on startup.
    torch = None
    nn = None
    TORCH_AVAILABLE = False

# The 6 real experiment steps, plus 2 "meta" classes the spec calls for:
# Unknown_Action (recognizer isn't confident about anything) and Wait
# (person is present but not doing an experiment step right now).
ACTIVITY_CLASSES = [
    "Pick_Container",
    "Open_Container",
    "Add_Sample",
    "Close_Container",
    "Place_Analyzer",
    "Record_Result",
    "Unknown_Action",
    "Wait",
]

# Matches pose_detector._TRACKED_JOINTS — 12 joints x 4 values (x, y, z, visibility).
NUM_JOINTS = 12
FEATURES_PER_JOINT = 4
INPUT_SIZE = NUM_JOINTS * FEATURES_PER_JOINT  # 48

# Where a real trained checkpoint would live, if one existed.
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "..", "models")
MODEL_PATH = os.path.abspath(os.path.join(MODEL_DIR, "activity_lstm.pt"))

SEQUENCE_LENGTH = 30  # how many frames of landmarks make up one prediction window


if TORCH_AVAILABLE:
    class ActivityLSTM(nn.Module):
        """
        Real architecture, ready for real training later — not used
        for inference anywhere in this prototype since it has no
        trained weights. Input: a (batch, SEQUENCE_LENGTH, INPUT_SIZE)
        tensor of per-frame joint coordinates. Output: raw class
        logits over the 6 real activity classes (the two meta classes
        are derived from confidence at inference time instead).
        """

        def __init__(self, input_size=INPUT_SIZE, hidden_size=64, num_layers=2, num_classes=6):
            super().__init__()
            self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
            self.classifier = nn.Linear(hidden_size, num_classes)

        def forward(self, x):
            output, (hidden, _) = self.lstm(x)
            last_hidden = hidden[-1]
            return self.classifier(last_hidden)
else:
    ActivityLSTM = None


class ActivityModel:
    """The interface the rest of the app talks to — camera.py (or a
    future recognition loop) calls `predict(sequence)` and never needs
    to know whether a real model is loaded or not."""

    def __init__(self):
        self._model = None
        self._trained = False
        self._load_attempted = False

    def _try_load(self):
        """Looks for a real checkpoint on disk. Does nothing (and sets
        no error) if one doesn't exist — that's the expected state for
        this prototype, not a failure."""
        self._load_attempted = True
        if not TORCH_AVAILABLE:
            return
        if not os.path.isfile(MODEL_PATH):
            return
        try:
            model = ActivityLSTM()
            state_dict = torch.load(MODEL_PATH, map_location="cpu")
            model.load_state_dict(state_dict)
            model.eval()
            self._model = model
            self._trained = True
        except Exception:
            # A corrupted or incompatible checkpoint should degrade to
            # "not trained," never crash the backend.
            self._model = None
            self._trained = False

    def is_trained(self) -> bool:
        if not self._load_attempted:
            self._try_load()
        return self._trained

    def predict(self, sequence) -> dict:
        """
        sequence: a list of per-frame landmark dicts, each shaped like
        pose_detector's output (e.g. {"left_shoulder": {"x":.., "y":..,
        "z":.., "visibility":..}, ...}). Length doesn't need to exactly
        match SEQUENCE_LENGTH — a real model would pad/truncate.

        Returns {"activity": str, "confidence": float, "trained": bool}.
        `activity` is "AI_MODEL_NOT_TRAINED" whenever `trained` is
        False — this is a deliberate, honest sentinel value, not a
        real class from ACTIVITY_CLASSES.
        """
        if not self.is_trained():
            return {"activity": "AI_MODEL_NOT_TRAINED", "confidence": 0.0, "trained": False}

        # This branch only runs once a real checkpoint has been placed
        # at MODEL_PATH and successfully loaded — not exercised by
        # this prototype, but here so training a model later is a
        # drop-in change rather than a rewrite.
        tensor = self._sequence_to_tensor(sequence)
        with torch.no_grad():
            logits = self._model(tensor)
            probs = torch.softmax(logits, dim=-1)
            confidence, predicted_idx = torch.max(probs, dim=-1)
        activity = ACTIVITY_CLASSES[predicted_idx.item()]
        return {"activity": activity, "confidence": round(confidence.item() * 100, 2), "trained": True}

    def _sequence_to_tensor(self, sequence):
        """Flattens a list of landmark-dicts into a (1, T, INPUT_SIZE) tensor."""
        from app.ai.pose_detector import _TRACKED_JOINTS

        rows = []
        for frame_landmarks in sequence[-SEQUENCE_LENGTH:]:
            row = []
            for joint in _TRACKED_JOINTS:
                point = frame_landmarks.get(joint, {"x": 0.0, "y": 0.0, "z": 0.0, "visibility": 0.0})
                row.extend([point["x"], point["y"], point["z"], point["visibility"]])
            rows.append(row)
        return torch.tensor([rows], dtype=torch.float32)


# Single shared instance.
activity_model = ActivityModel()
