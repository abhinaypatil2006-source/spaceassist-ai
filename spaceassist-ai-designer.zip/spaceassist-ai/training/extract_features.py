"""
extract_features.py — Step 2 of the training pipeline.

Walks through every image in ../dataset/<Activity>/, runs MediaPipe
Pose on it, and converts the detected body landmarks into a numerical
feature vector. All vectors + labels are saved into
../dataset/features.csv, which train_model.py reads next.

USAGE (from the training/ folder, with your venv activated):
    python extract_features.py

Images where no person/pose could be detected are safely skipped
(not filled with fake zeros pretending to be real data) — the script
reports exactly how many were skipped per activity so you know if you
need to re-record clearer footage.
"""

import os
import csv
import cv2
import mediapipe as mp

DATASET_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "dataset")
OUTPUT_CSV = os.path.join(DATASET_DIR, "features.csv")

ACTIVITIES = [
    "Pick_Container",
    "Open_Container",
    "Add_Sample",
    "Close_Container",
    "Place_Analyzer",
    "Record_Result",
]

# The same 12 joints used throughout SpaceAssist AI (see
# backend/app/ai/pose_detector.py) so this feature format stays
# consistent with the rest of the project.
TRACKED_JOINTS = [
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]

mp_pose = mp.solutions.pose


def extract_landmark_vector(pose_landmarks) -> list:
    """Returns a flat list of [x, y, z, visibility] x 12 joints = 48 numbers."""
    landmark_enum = mp_pose.PoseLandmark
    row = []
    for joint_name in TRACKED_JOINTS:
        enum_member = landmark_enum[joint_name.upper()]
        lm = pose_landmarks.landmark[enum_member]
        row.extend([lm.x, lm.y, lm.z, lm.visibility])
    return row


def main():
    if not os.path.isdir(DATASET_DIR):
        print(f"ERROR: Dataset folder not found at {DATASET_DIR}")
        print("Run collect_data.py first, or create the dataset/<Activity> folders manually.")
        return

    pose = mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5)

    header = ["label"] + [f"{joint}_{axis}" for joint in TRACKED_JOINTS for axis in ("x", "y", "z", "v")]
    rows = []
    skipped_counts = {}
    processed_counts = {}

    for activity in ACTIVITIES:
        folder = os.path.join(DATASET_DIR, activity)
        skipped_counts[activity] = 0
        processed_counts[activity] = 0

        if not os.path.isdir(folder):
            print(f"WARNING: No folder found for {activity}, skipping.")
            continue

        image_files = [f for f in os.listdir(folder) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
        print(f"Processing {activity}: {len(image_files)} image(s) found...")

        for filename in image_files:
            path = os.path.join(folder, filename)
            image = cv2.imread(path)
            if image is None:
                skipped_counts[activity] += 1
                continue

            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            result = pose.process(image_rgb)

            if result.pose_landmarks is None:
                # No person detected in this image — skip it rather
                # than inventing a fake all-zero feature row, which
                # would quietly poison the training data.
                skipped_counts[activity] += 1
                continue

            feature_vector = extract_landmark_vector(result.pose_landmarks)
            rows.append([activity] + feature_vector)
            processed_counts[activity] += 1

    pose.close()

    if not rows:
        print()
        print("=" * 60)
        print(" NO USABLE DATA FOUND.")
        print(" No images produced a detectable pose across any activity.")
        print(" Record clearer footage (good lighting, full body visible)")
        print(" with collect_data.py before running this script again.")
        print("=" * 60)
        return

    with open(OUTPUT_CSV, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print()
    print("=" * 60)
    print(" Feature extraction complete.")
    print(f" Saved to: {OUTPUT_CSV}")
    print()
    print(f" {'Activity':<20} {'Used':>8} {'Skipped':>8}")
    for activity in ACTIVITIES:
        print(f" {activity:<20} {processed_counts[activity]:>8} {skipped_counts[activity]:>8}")
    total_used = sum(processed_counts.values())
    total_skipped = sum(skipped_counts.values())
    print(f" {'TOTAL':<20} {total_used:>8} {total_skipped:>8}")
    print("=" * 60)

    low_data_activities = [a for a in ACTIVITIES if processed_counts[a] < 20]
    if low_data_activities:
        print()
        print("NOTE: These activities have fewer than 20 usable samples,")
        print("which is too little to train a reliable model:")
        for a in low_data_activities:
            print(f"   - {a}: only {processed_counts[a]} usable samples")
        print("Collect more footage for these before training, or expect")
        print("train_model.py to honestly report low accuracy.")


if __name__ == "__main__":
    main()
