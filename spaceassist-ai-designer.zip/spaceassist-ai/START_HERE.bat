@echo off
REM ============================================================
REM SpaceAssist AI - ONE-CLICK STARTER
REM Just double-click this file. It does everything:
REM   1. Opens the backend in its own window
REM   2. Opens the frontend in its own window
REM   3. Opens your browser to the app automatically
REM ============================================================

echo.
echo ============================================================
echo  SpaceAssist AI - Starting everything...
echo ============================================================
echo.
echo This will open TWO new black windows. That is normal.
echo DO NOT CLOSE those windows while you are using the app.
echo.
echo Starting backend...
start "SpaceAssist AI - BACKEND (do not close)" cmd /k "%~dp0start_backend.bat"

echo Waiting for backend to warm up...
timeout /t 8 /nobreak > nul

echo Starting frontend...
start "SpaceAssist AI - FRONTEND (do not close)" cmd /k "%~dp0start_frontend.bat"

echo Waiting for frontend to warm up...
timeout /t 8 /nobreak > nul

echo Opening the app in your browser...
start http://localhost:5173

echo.
echo ============================================================
echo  Done! The app should now be open in your browser.
echo  If not, manually open: http://localhost:5173
echo.
echo  Two windows are running in the background - leave them
echo  open the whole time you are using or demoing the app.
echo ============================================================
echo.
pause
