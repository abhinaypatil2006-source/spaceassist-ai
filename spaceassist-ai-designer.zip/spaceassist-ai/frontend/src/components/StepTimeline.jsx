const TONE_STYLES = {
  CORRECT: { border: 'var(--status-nominal)', fill: 'var(--status-nominal)', text: 'var(--bg-void)' },
  IN_PROGRESS: { border: 'var(--status-active)', fill: 'transparent', text: 'var(--status-active)' },
  PENDING: { border: 'var(--border-hairline)', fill: 'transparent', text: 'var(--text-dim)' },
}

function Node({ step }) {
  const style = TONE_STYLES[step.status] ?? TONE_STYLES.PENDING
  const isActive = step.status === 'IN_PROGRESS'
  const isDone = step.status === 'CORRECT'

  return (
    <div className="step-node">
      <div
        className={`step-node__marker${isActive ? ' step-node__marker--active' : ''}`}
        style={{ borderColor: style.border, background: style.fill }}
      >
        <span className="mono" style={{ color: isDone ? style.text : style.border, fontSize: 12, fontWeight: 600 }}>
          {isDone ? '✓' : step.step_index + 1}
        </span>
      </div>
      <div className="step-node__label">
        <div
          style={{
            color: isActive ? 'var(--text-primary)' : isDone ? 'var(--text-secondary)' : 'var(--text-muted)',
            fontWeight: isActive ? 600 : 500,
            fontSize: 13.5,
          }}
        >
          {step.step_name}
        </div>
        <div className="eyebrow" style={{ marginTop: 2, color: style.border }}>
          {step.status === 'CORRECT' ? 'Confirmed' : step.status === 'IN_PROGRESS' ? 'In Progress' : 'Pending'}
        </div>
      </div>
    </div>
  )
}

/**
 * Renders the 6 experiment steps as a connected signal path — the
 * hexagonal, instrument-panel-style nodes are the page's signature
 * element, standing in for the literal step sequence of the
 * Sample Processing Experiment.
 */
export default function StepTimeline({ steps }) {
  return (
    <div className="step-timeline">
      {steps.map((step, i) => (
        <div key={step.step_index} className="step-timeline__row">
          <Node step={step} />
          {i < steps.length - 1 && (
            <div
              className="step-timeline__connector"
              style={{
                background: step.status === 'CORRECT' ? 'var(--status-nominal)' : 'var(--border-hairline)',
              }}
            />
          )}
        </div>
      ))}
    </div>
  )
}
