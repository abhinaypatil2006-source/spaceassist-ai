import { createContext, useContext, useCallback, useEffect, useRef, useState } from 'react'
import {
  getExperiment,
  getHistory,
  getAlerts,
  startExperiment,
  resetExperiment,
  startDemo,
  stopDemo,
  getDemoStatus,
  getCameraStatus,
  startCamera,
  stopCamera,
  startCustomExperiment,
  advanceExperiment,
  startRecordingSession,
  stopRecordingSession,
  clearRecordingSession,
  getRecordingStatus,
} from '../services/api'
import { DEFAULT_EXPERIMENT } from '../constants'

const WS_URL = 'ws://127.0.0.1:8000/api/ws'
const POLL_INTERVAL_MS = 2000
const WS_RETRY_MS = 3000
const FETCH_TIMEOUT_MS = 4000

const ExperimentContext = createContext(null)

/**
 * Wraps a promise with a hard timeout. Without this, a single hung
 * fetch (network hiccup, backend endpoint that never responds) could
 * leave a Promise.all() waiting forever — freezing the entire
 * dashboard silently, with no error shown and no way to recover
 * short of a page refresh. A real bug found via a screenshot showing
 * exactly this: the UI frozen mid-update while the backend had
 * already moved on.
 */
function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out`)), ms)),
  ])
}

/**
 * Single source of truth for live experiment data.
 *
 * Two transports feed it, on purpose:
 *  - WebSocket (/api/ws): pushes an instant refresh signal the moment
 *    the backend's state changes (start / predict / reset).
 *  - REST polling (every 2s): a fallback so the dashboard still stays
 *    current if the WebSocket can't connect (e.g. a network that
 *    blocks the upgrade) — and it also detects when the backend goes
 *    down or comes back up.
 */
export function ExperimentProvider({ children }) {
  const [experiment, setExperiment] = useState(null)
  const [history, setHistory] = useState([])
  const [alerts, setAlerts] = useState([])
  const [demoRunning, setDemoRunning] = useState(false)
  const [cameraStatus, setCameraStatus] = useState({ available: false, streaming: false, message: 'Checking camera…' })
  const [recordingStatus, setRecordingStatus] = useState({ recording: false, frames_recorded: 0, current_label: null, label_counts: {} })
  const [connectionStatus, setConnectionStatus] = useState('connecting') // connecting | live | polling | offline
  const [actionError, setActionError] = useState(null)
  const wsRef = useRef(null)
  const retryTimerRef = useRef(null)

  const refresh = useCallback(async () => {
    const results = await Promise.allSettled([
      withTimeout(getExperiment(), FETCH_TIMEOUT_MS, 'getExperiment'),
      withTimeout(getHistory(), FETCH_TIMEOUT_MS, 'getHistory'),
      withTimeout(getAlerts(), FETCH_TIMEOUT_MS, 'getAlerts'),
      withTimeout(getDemoStatus(), FETCH_TIMEOUT_MS, 'getDemoStatus'),
      withTimeout(getCameraStatus(), FETCH_TIMEOUT_MS, 'getCameraStatus'),
      withTimeout(getRecordingStatus(), FETCH_TIMEOUT_MS, 'getRecordingStatus'),
    ])
    const [exp, hist, al, demo, cam, rec] = results

    // Apply whichever calls actually succeeded — a single slow or
    // failed endpoint no longer blocks the other five from updating,
    // and no longer freezes the dashboard indefinitely with stale data.
    if (exp.status === 'fulfilled') setExperiment(exp.value)
    if (hist.status === 'fulfilled') setHistory(hist.value)
    if (al.status === 'fulfilled') setAlerts(al.value)
    if (demo.status === 'fulfilled') setDemoRunning(demo.value.running)
    if (cam.status === 'fulfilled') setCameraStatus(cam.value)
    if (rec.status === 'fulfilled') setRecordingStatus(rec.value)

    const allFailed = results.every((r) => r.status === 'rejected')
    if (allFailed) {
      setConnectionStatus('offline')
    } else {
      setConnectionStatus((prev) => (prev === 'connecting' ? 'polling' : prev === 'offline' ? 'polling' : prev))
    }
  }, [])

  useEffect(() => {
    refresh()

    let cancelled = false

    function connectWebSocket() {
      if (cancelled) return
      try {
        const ws = new WebSocket(WS_URL)
        wsRef.current = ws

        ws.onopen = () => setConnectionStatus('live')
        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data)
            if (data.event === "demo_error") {
              setActionError(data.message)
            }
          } catch {
            // Non-JSON or unexpected payload — refresh() below still
            // covers us either way, so this isn't fatal.
          }
          refresh()
        }
        ws.onclose = () => {
          if (cancelled) return
          setConnectionStatus((prev) => (prev === 'offline' ? 'offline' : 'polling'))
          retryTimerRef.current = setTimeout(connectWebSocket, WS_RETRY_MS)
        }
        ws.onerror = () => {
          ws.close()
        }
      } catch {
        setConnectionStatus('polling')
        retryTimerRef.current = setTimeout(connectWebSocket, WS_RETRY_MS)
      }
    }

    connectWebSocket()
    const pollId = setInterval(refresh, POLL_INTERVAL_MS)

    return () => {
      cancelled = true
      clearInterval(pollId)
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current)
      if (wsRef.current) wsRef.current.close()
    }
  }, [refresh])

  const start = useCallback(
    async (mode = 'DEMO') => {
      setActionError(null)
      try {
        await startExperiment(mode)
        await refresh()
      } catch (e) {
        setActionError(e.message)
      }
    },
    [refresh]
  )

  const reset = useCallback(async () => {
    setActionError(null)
    try {
      await resetExperiment()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const runDemo = useCallback(async () => {
    setActionError(null)
    try {
      await startDemo()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const haltDemo = useCallback(async () => {
    setActionError(null)
    try {
      await stopDemo()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const beginCamera = useCallback(async () => {
    setActionError(null)
    try {
      await startCamera()
      await refresh()
    } catch (e) {
      setActionError(e.message)
      await refresh()
    }
  }, [refresh])

  const endCamera = useCallback(async () => {
    setActionError(null)
    try {
      await stopCamera()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const startCustom = useCallback(
    async (name, steps) => {
      setActionError(null)
      try {
        await startCustomExperiment(name, steps)
        await refresh()
        return true
      } catch (e) {
        setActionError(e.message)
        return false
      }
    },
    [refresh]
  )

  const advanceStep = useCallback(async () => {
    setActionError(null)
    try {
      await advanceExperiment()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const beginRecording = useCallback(async () => {
    setActionError(null)
    try {
      await startRecordingSession()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const endRecording = useCallback(async () => {
    setActionError(null)
    try {
      await stopRecordingSession()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const wipeRecording = useCallback(async () => {
    setActionError(null)
    try {
      await clearRecordingSession()
      await refresh()
    } catch (e) {
      setActionError(e.message)
    }
  }, [refresh])

  const value = {
    experiment: experiment ?? DEFAULT_EXPERIMENT,
    hasLoaded: experiment !== null,
    history,
    alerts,
    demoRunning,
    cameraStatus,
    recordingStatus,
    connectionStatus,
    actionError,
    refresh,
    start,
    reset,
    runDemo,
    haltDemo,
    beginCamera,
    endCamera,
    startCustom,
    advanceStep,
    beginRecording,
    endRecording,
    wipeRecording,
  }

  return <ExperimentContext.Provider value={value}>{children}</ExperimentContext.Provider>
}

export function useExperiment() {
  const ctx = useContext(ExperimentContext)
  if (!ctx) throw new Error('useExperiment must be used within an ExperimentProvider')
  return ctx
}

/**
 * Derives a "latest activity" readout from the history log, since the
 * backend doesn't persist a standalone "last prediction" record.
 */
export function getLatestActivity(history, experiment) {
  if (!history || history.length === 0) {
    if (experiment.status === 'COMPLETED') {
      return { status: 'COMPLETED', expected: null, detected: '—', confidence: 100, message: 'Experiment completed successfully.' }
    }
    if (experiment.status === 'IN_PROGRESS') {
      const expectedStep = experiment.steps[experiment.current_step_index]
      return {
        status: 'IN_PROGRESS',
        expected: expectedStep?.step_name ?? null,
        detected: '—',
        confidence: 0,
        message: 'Waiting for the first prediction…',
      }
    }
    return { status: 'NOT_STARTED', expected: null, detected: '—', confidence: 0, message: 'Start the experiment to begin monitoring.' }
  }
  const last = history[history.length - 1]
  return { ...last }
}
