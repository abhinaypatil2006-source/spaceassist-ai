import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import ConfidenceGauge from '../components/ConfidenceGauge'
import StepTimeline from '../components/StepTimeline'
import StatusPill from '../components/StatusPill'
import BrowserCamera from '../components/BrowserCamera'
import { useExperiment, getLatestActivity } from '../context/ExperimentContext'
import { CONFIDENCE_THRESHOLDS } from '../constants'
import {
  CAMERA_STREAM_URL,
  RECORDING_DOWNLOAD_URL,
  getCameraObservations,
  clearCameraObservations,
  OBSERVATIONS_DOWNLOAD_URL,
  getActivityReportStatus,
  resetActivityReport,
  REPORT_DOWNLOAD_TXT_URL,
  REPORT_DOWNLOAD_JSON_URL,
  REPORT_DOWNLOAD_PDF_URL,
} from '../services/api'

const OBSERVATION_POLL_MS = 2000

export default function LiveExperiment() {
  const {
    experiment,
    history,
    demoRunning,
    cameraStatus,
    recordingStatus,
    actionError,
    start,
    reset,
    runDemo,
    beginCamera,
    endCamera,
    advanceStep,
    beginRecording,
    endRecording,
    wipeRecording,
  } = useExperiment()
  const latest = getLatestActivity(history, experiment)
  const [pending, setPending] = useState(null)
  const [streamKey, setStreamKey] = useState(0) // bump to force <img> to reconnect the MJPEG stream
  const [observations, setObservations] = useState([])
  const [reportStatus, setReportStatus] = useState({ total_activity_events: 0, recent_events: [] })

  // Only poll the observation log + activity report while the camera
  // is actually streaming — no point hitting these endpoints elsewhere.
  useEffect(() => {
    if (!cameraStatus.streaming) return
    let cancelled = false
    const poll = async () => {
      try {
        const [obsData, reportData] = await Promise.all([getCameraObservations(), getActivityReportStatus()])
        if (!cancelled) {
          setObservations(obsData.entries)
          setReportStatus(reportData)
        }
      } catch {
        // camera page still works fine without this; just skip a beat
      }
    }
    poll()
    const id = setInterval(poll, OBSERVATION_POLL_MS)
    return () => {
      cancelled = true
      clearInterval(id)
    }
  }, [cameraStatus.streaming])

  const handleClearObservations = async () => {
    await clearCameraObservations()
    setObservations([])
  }

  const handleResetReport = async () => {
    await resetActivityReport()
    setReportStatus({ total_activity_events: 0, recent_events: [] })
  }

  const isRunning = experiment.status === 'IN_PROGRESS'
  const isCompleted = experiment.status === 'COMPLETED'
  const anyBusy = pending !== null || demoRunning

  const run = (key, fn) => async () => {
    setPending(key)
    await fn()
    setPending(null)
  }

  const handleStart = run('start', () => start('DEMO'))
  const handleReset = run('reset', reset)
  const handleDemo = run('demo', runDemo)
  const handleAdvance = run('advance', advanceStep)
  const handleCameraStart = run('camera-start', async () => {
    await beginCamera()
    setStreamKey((k) => k + 1)
  })
  const handleCameraStop = run('camera-stop', endCamera)
  const handleRecordStart = run('record-start', beginRecording)
  const handleRecordStop = run('record-stop', endRecording)
  const handleRecordClear = run('record-clear', wipeRecording)

  return (
    <div className="live-page">
      <section className="panel live-controls">
        <div className="panel-header">
          <span className="panel-title">Demo Control</span>
          {demoRunning ? (
            <span className="pill pill--active">
              <span className="pill-dot" />
              Demo Running
            </span>
          ) : (
            <Link to="/design" className="dashboard-link">
              + Design a new science experiment
            </Link>
          )}
        </div>
        <div className="live-controls__buttons">
          <button className="btn btn--primary" onClick={handleStart} disabled={anyBusy || isRunning}>
            {pending === 'start' ? 'Starting…' : 'Start Experiment'}
          </button>
          <button className="btn btn--primary" onClick={handleDemo} disabled={anyBusy}>
            {pending === 'demo' || demoRunning ? 'Running Demo…' : 'Start Demo'}
          </button>
          <button
            className="btn"
            onClick={handleCameraStart}
            disabled={pending !== null || cameraStatus.streaming || !cameraStatus.available}
            title={!cameraStatus.available ? cameraStatus.message : undefined}
          >
            {pending === 'camera-start' ? 'Starting…' : 'Start Camera'}
          </button>
          <button className="btn" onClick={handleCameraStop} disabled={pending !== null || !cameraStatus.streaming}>
            {pending === 'camera-stop' ? 'Stopping…' : 'Stop Camera'}
          </button>
          <button className="btn btn--danger" onClick={handleReset} disabled={pending !== null}>
            {pending === 'reset' ? 'Resetting…' : 'Reset Experiment'}
          </button>
        </div>
        {actionError && <div className="live-controls__error">⚠ {actionError}</div>}
        {demoRunning && (
          <div className="live-controls__hint">
            Demo Mode is feeding a scripted sequence of predictions automatically — including one
            intentional wrong action, so you can see the sequence-error warning fire live.
          </div>
        )}
        {!demoRunning && isRunning && experiment.is_custom && (
          <div className="live-controls__advance">
            <button className="btn btn--primary" onClick={handleAdvance} disabled={pending !== null}>
              {pending === 'advance' ? 'Marking…' : `✓ Mark "${experiment.steps[experiment.current_step_index]?.step_name ?? 'Step'}" Complete`}
            </button>
            <span className="eyebrow">Guiding: {experiment.name}</span>
          </div>
        )}
        {!demoRunning && isRunning && !experiment.is_custom && (
          <div className="live-controls__hint">
            Experiment is running manually. Send predictions to <code>POST /api/ai/predict</code> to
            advance it, or click <strong>Start Demo</strong> to see it run automatically.
          </div>
        )}
        {!demoRunning && isCompleted && <div className="live-controls__hint">✓ Experiment completed. Reset to run again.</div>}
      </section>

      <div className="dashboard-grid" style={{ marginTop: 20 }}>
        <section className="panel dashboard-hud">
          <div className="panel-header">
            <span className="panel-title">Live Readout</span>
            <StatusPill status={latest.status} />
          </div>
          <div className="dashboard-hud__body">
            <div className="dashboard-hud__readout">
              <div className="dashboard-hud__row">
                <span className="eyebrow">Detected</span>
                <span className="dashboard-hud__value">{latest.detected ?? '—'}</span>
              </div>
              <div className="dashboard-hud__row">
                <span className="eyebrow">Expected</span>
                <span className="dashboard-hud__value dashboard-hud__value--muted">{latest.expected ?? '—'}</span>
              </div>
              <p className="dashboard-hud__message">{latest.message}</p>
            </div>
            <ConfidenceGauge confidence={latest.confidence ?? 0} thresholds={CONFIDENCE_THRESHOLDS} />
          </div>
        </section>

        <section className="panel dashboard-steps">
          <div className="panel-header">
            <span className="panel-title">Experiment Timeline</span>
            <span className="mono" style={{ fontSize: 12, color: 'var(--text-muted)' }}>
              {experiment.progress}
            </span>
          </div>
          <div className="dashboard-steps__body">
            <StepTimeline steps={experiment.steps} />
          </div>
        </section>

        <section className="panel">
          <div className="panel-header">
            <span className="panel-title">Camera Feed</span>
            {cameraStatus.streaming && (
              <span className="pill pill--nominal">
                <span className="pill-dot" />
                Live
              </span>
            )}
          </div>
          {cameraStatus.streaming ? (
            <div className="camera-live">
              <img
                key={streamKey}
                src={`${CAMERA_STREAM_URL}?t=${streamKey}`}
                alt="Live webcam feed"
                className="camera-live__frame"
                onError={() => endCamera()}
              />
              <div className="camera-live__stats">
                <span className={`pill ${cameraStatus.person_detected ? 'pill--nominal' : 'pill--pending'}`}>
                  <span className="pill-dot" />
                  {cameraStatus.person_detected ? 'Person Detected' : 'No Person Detected'}
                </span>
                <span className="pill pill--active">
                  <span className="pill-dot" />
                  Hands: {cameraStatus.hands_detected ?? 0}
                </span>
                <span className={`pill ${cameraStatus.model_trained ? 'pill--nominal' : 'pill--caution'}`}>
                  <span className="pill-dot" />
                  AI: {cameraStatus.ai_activity ?? 'AI_MODEL_NOT_TRAINED'}
                </span>
              </div>
              <p className="camera-live__note">
                {cameraStatus.mediapipe_installed
                  ? 'MediaPipe pose + hand landmarks are drawn live on the feed above.'
                  : 'MediaPipe is not installed — showing raw video only. Run `pip install mediapipe`.'}
              </p>

              <div className="recorder-panel">
                <div className="recorder-panel__header">
                  <span className="eyebrow">Auto-Labeled Training Recorder</span>
                  {recordingStatus.recording && (
                    <span className="pill pill--error">
                      <span className="pill-dot" />
                      REC {recordingStatus.frames_recorded}
                    </span>
                  )}
                </div>
                <p className="recorder-panel__note">
                  Records your pose while you perform the real steps, automatically labeled with
                  whatever step the experiment currently expects — real training data, in the exact
                  format <code>training/train_model.py</code> reads. Start an experiment first so
                  there's a step to label with.
                </p>
                {recordingStatus.current_label && recordingStatus.recording && (
                  <div className="recorder-panel__current">
                    Currently labeling as: <strong>{recordingStatus.current_label}</strong>
                  </div>
                )}
                <div className="recorder-panel__buttons">
                  {!recordingStatus.recording ? (
                    <button
                      className="btn btn--primary"
                      onClick={handleRecordStart}
                      disabled={pending !== null || !isRunning}
                      title={!isRunning ? 'Start an experiment first' : undefined}
                    >
                      {pending === 'record-start' ? 'Starting…' : '● Start Recording Session'}
                    </button>
                  ) : (
                    <button className="btn btn--danger" onClick={handleRecordStop} disabled={pending !== null}>
                      {pending === 'record-stop' ? 'Stopping…' : '■ Stop Recording'}
                    </button>
                  )}
                  <a
                    className={`btn ${recordingStatus.frames_recorded === 0 ? 'btn--disabled-link' : ''}`}
                    href={recordingStatus.frames_recorded > 0 ? RECORDING_DOWNLOAD_URL : undefined}
                    onClick={(e) => recordingStatus.frames_recorded === 0 && e.preventDefault()}
                  >
                    Download .csv
                  </a>
                  <button
                    className="btn"
                    onClick={handleRecordClear}
                    disabled={pending !== null || recordingStatus.frames_recorded === 0}
                  >
                    Clear
                  </button>
                </div>
                {Object.keys(recordingStatus.label_counts ?? {}).length > 0 && (
                  <div className="recorder-panel__counts">
                    {Object.entries(recordingStatus.label_counts).map(([label, count]) => (
                      <span key={label} className="pill pill--pending">
                        <span className="pill-dot" />
                        {label}: {count}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="movement-log">
                <div className="movement-log__header">
                  <span className="eyebrow">Camera Observation Log ({observations.length})</span>
                  <div className="movement-log__actions">
                    <button className="btn" onClick={handleClearObservations} disabled={observations.length === 0}>
                      Clear
                    </button>
                    <a
                      className={`btn ${observations.length === 0 ? 'btn--disabled-link' : ''}`}
                      href={observations.length > 0 ? OBSERVATIONS_DOWNLOAD_URL : undefined}
                      onClick={(e) => observations.length === 0 && e.preventDefault()}
                    >
                      Download .txt
                    </a>
                  </div>
                </div>
                <div className="movement-log__body scrollbar-thin">
                  {observations.length === 0 ? (
                    <div className="empty-state">Watching for what the camera sees, once per second…</div>
                  ) : (
                    observations
                      .slice()
                      .reverse()
                      .map((entry, i) => (
                        <div key={i} className="mono movement-log__line">
                          {new Date(entry.timestamp).toLocaleTimeString('en-US', { hour12: false })} {entry.text}
                        </div>
                      ))
                  )}
                </div>
              </div>

              <div className="recorder-panel">
                <div className="recorder-panel__header">
                  <span className="eyebrow">Activity Report — Camera → Motion → Report</span>
                  <span className="pill pill--active">
                    <span className="pill-dot" />
                    {reportStatus.total_activity_events} events
                  </span>
                </div>
                <p className="recorder-panel__note">
                  Turns what the camera sees into a narrative report — person entered, moved left to
                  right, stopped, left the camera view — built from real detected motion and
                  presence, not a guess. Download it once you've captured a session.
                </p>
                {reportStatus.recent_events?.length > 0 && (
                  <div className="recorder-panel__current">
                    Latest: <strong>{reportStatus.recent_events[reportStatus.recent_events.length - 1].description}</strong>
                  </div>
                )}
                <div className="recorder-panel__buttons">
                  <a className="btn" href={REPORT_DOWNLOAD_TXT_URL}>
                    Download .txt
                  </a>
                  <a className="btn" href={REPORT_DOWNLOAD_JSON_URL}>
                    Download .json
                  </a>
                  <a className="btn btn--primary" href={REPORT_DOWNLOAD_PDF_URL}>
                    Download .pdf
                  </a>
                  <button className="btn btn--danger" onClick={handleResetReport}>
                    Reset Report
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="camera-placeholder">
              <BrowserCamera />
              <div className="camera-placeholder__backend-note">
                <span className="eyebrow">AI-powered feed (pose landmarks) status:</span>
                <p className="camera-placeholder__message">{cameraStatus.message}</p>
                {cameraStatus.opencv_installed === false ? (
                  <span className="pill pill--caution">
                    <span className="pill-dot" />
                    OpenCV Not Installed
                  </span>
                ) : (
                  <span className="pill pill--pending">
                    <span className="pill-dot" />
                    Camera Unavailable
                  </span>
                )}
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
