import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useExperiment } from '../context/ExperimentContext'

const EXAMPLE = {
  name: 'Plant Growth Under Microgravity',
  steps: [
    'Unpack seed cartridge from storage',
    'Insert cartridge into germination chamber',
    'Calibrate LED grow light intensity',
    'Record initial moisture sensor reading',
    'Activate 72-hour observation timer',
  ],
}

export default function DesignExperiment() {
  const { startCustom, actionError } = useExperiment()
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [stepsText, setStepsText] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const stepLines = stepsText
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)

  const canSubmit = name.trim().length > 0 && stepLines.length > 0 && !submitting

  const handleLoadExample = () => {
    setName(EXAMPLE.name)
    setStepsText(EXAMPLE.steps.join('\n'))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!canSubmit) return
    setSubmitting(true)
    const ok = await startCustom(name.trim(), stepLines)
    setSubmitting(false)
    if (ok) {
      navigate('/live')
    }
  }

  return (
    <div className="page-single">
      <section className="panel">
        <div className="panel-header">
          <span className="panel-title">Design a Science Experiment</span>
          <button
            type="button"
            className="dashboard-link"
            onClick={handleLoadExample}
            style={{ background: 'none', border: 'none', cursor: 'pointer' }}
          >
            Load example
          </button>
        </div>

        <div className="designer-intro">
          <p>
            Type in <strong>any</strong> science procedure — not just the built-in Sample
            Processing Experiment — as a name and an ordered list of steps. The app reads it and
            guides the astronaut through it, one step at a time, with the same live tracking,
            timeline, and logging as everywhere else in the dashboard.
          </p>
          <p className="designer-intro__honest">
            Honest note: since this procedure is typed in fresh, there's no trained camera model
            that could recognize these exact steps automatically. Progress here is confirmed
            manually — a "Mark Step Complete" button on the Live Experiment page — the same way an
            astronaut would tick off a checklist. That's a deliberate choice, not a shortcut: it's
            the same honesty this whole project is built on.
          </p>
        </div>

        <form className="designer-form" onSubmit={handleSubmit}>
          <label className="designer-form__label" htmlFor="exp-name">
            Experiment name
          </label>
          <input
            id="exp-name"
            className="settings-input designer-form__name-input"
            type="text"
            placeholder="e.g. Protein Crystal Growth"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={120}
          />

          <label className="designer-form__label" htmlFor="exp-steps">
            Steps — one per line, in order
          </label>
          <textarea
            id="exp-steps"
            className="designer-form__textarea mono"
            placeholder={'Unpack seed cartridge from storage\nInsert cartridge into germination chamber\nCalibrate LED grow light intensity\n...'}
            value={stepsText}
            onChange={(e) => setStepsText(e.target.value)}
            rows={10}
          />
          <div className="designer-form__count eyebrow">
            {stepLines.length} step{stepLines.length === 1 ? '' : 's'} entered (1–25 allowed)
          </div>

          {actionError && <div className="live-controls__error">⚠ {actionError}</div>}

          <button type="submit" className="btn btn--primary designer-form__submit" disabled={!canSubmit}>
            {submitting ? 'Starting…' : 'Start This Experiment'}
          </button>
        </form>
      </section>
    </div>
  )
}
