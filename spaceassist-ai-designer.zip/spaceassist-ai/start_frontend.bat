@echo off
REM ============================================================
REM SpaceAssist AI - Frontend Launcher
REM Run this AFTER start_backend.bat is already running in
REM another window. Double-click this file to set up and start
REM the dashboard automatically. Safe to run multiple times.
REM ============================================================

cd /d "%~dp0frontend"

echo.
echo ============================================================
echo  SpaceAssist AI - Frontend Setup
echo ============================================================
echo.

if not exist node_modules (
    echo [1/2] Installing frontend dependencies - first run only...
    call npm install
) else (
    echo [1/2] Dependencies already installed, skipping.
)

echo [2/2] Starting dashboard on http://localhost:5173 ...
echo.
echo   Make sure start_backend.bat is already running in another
echo   window before using the dashboard.
echo   Leave this window open while demoing. Press CTRL+C to stop.
echo.

call npm run dev

pause
